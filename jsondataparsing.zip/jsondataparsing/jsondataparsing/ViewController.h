//
//  ViewController.h
//  jsondataparsing
//
//  Created by MAC OS on 2/9/1938 Saka.
//  Copyright (c) 1938 Saka MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>

{
    
    NSMutableArray *arrdata;
    
    
}

@end

