//
//  main.m
//  jsondataparsing
//
//  Created by MAC OS on 2/9/1938 Saka.
//  Copyright (c) 1938 Saka MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
