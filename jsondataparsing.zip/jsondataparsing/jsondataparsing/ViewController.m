//
//  ViewController.m
//  jsondataparsing
//
//  Created by MAC OS on 2/9/1938 Saka.
//  Copyright (c) 1938 Saka MAC OS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    arrdata =[[NSMutableArray alloc]init];
    
    NSURL *url =[[NSURL alloc]initWithString:@"https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.series.upcoming&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback="];
    
    NSData *dt =[[NSData alloc]initWithContentsOfURL:url];
    
    
    NSDictionary *dic =[NSJSONSerialization JSONObjectWithData:dt options:kNilOptions error:nil];
    NSLog(@"%@",[dic description]);
    
    NSDictionary *dic1 =[dic valueForKey:@"query"];
    
    NSDictionary *dic2 =[dic1 valueForKey:@"results"];
    NSMutableArray *arr =[dic2 valueForKey:@"Series"];
    
    for ( NSDictionary *dic4 in arr) {
        
        NSMutableArray *temp =[[NSMutableArray alloc]init];
                               
        
        [temp addObject:[dic4 valueForKey:@"SeriesId"]];
        [temp addObject:[dic4 valueForKey:@"SeriesName"]];
        
        NSDictionary *dic5 =[dic4 valueForKey:@"Participant"];
        
        [temp addObject:[dic5 valueForKey:@"mlevel"]];
        
      //  NSDictionary *dic6 =[dic4 valueForKey:@"Schedule"];
        
        //NSMutableArray *brr =[dic6 valueForKey:@"Match"];
      
        
        
        [arrdata addObject:temp];
        
        
        
    }
    
    
    NSLog(@"%@",[arrdata description]);
    
    // Do any additional setup after loading the view, typically from a nib.
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   
    return 3;
    
   
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return [arrdata count];
    
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];

    NSMutableArray *temp =[[NSMutableArray alloc]init];
    
    temp =[arrdata objectAtIndex:indexPath.section];
    

    cell.textLabel.text=[temp objectAtIndex:indexPath.row];
    
    return cell;
    

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
